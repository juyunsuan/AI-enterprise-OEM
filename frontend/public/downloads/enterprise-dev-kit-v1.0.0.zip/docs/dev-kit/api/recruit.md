<!-- 自动生成，请勿手改。源：packages/contracts/src；命令：pnpm api:index -->

# 业务域：AI 简历代投（`recruit`）

> 自动派生摘要。完整 schema 在 `docs/api/openapi.json` 按 path 查找；不要整份加载。

| 操作 ID | 方法 | 路径 | 动作 | 读写 | 通道 | 路径参数 | 查询 | 请求体 | 响应 |
|---|---|---|---|---|---|---|---|---|---|
| `Recruit_listApplications` | GET | `/enterprise/recruit/applications` | 列表申请 | 读 | session(会话) |  | page, pageSize, status, jobId |  | data |
| `Recruit_confirmApplication` | POST | `/enterprise/recruit/applications/confirm` | 确认申请 | 写 | session(会话) |  |  | id | data |
| `Recruit_createApplication` | POST | `/enterprise/recruit/applications/create` | 新建申请 | 写 | session(会话) |  |  | jobId, resumeId, note, channel | data |
| `Recruit_events` | GET | `/enterprise/recruit/applications/events` | 事件 | 读 | session(会话) |  | applicationId |  | data |
| `Recruit_funnelStats` | GET | `/enterprise/recruit/applications/stats` | 漏斗统计 | 读 | session(会话) |  |  |  | data |
| `Recruit_updateApplicationStatus` | POST | `/enterprise/recruit/applications/status` | 修改申请状态 | 写 | session(会话) |  |  | id, status, note | data |
| `Recruit_patternInsights` | GET | `/enterprise/recruit/insights` | 规律洞察 | 读 | session(会话) |  |  |  | data |
| `Recruit_listJobs` | GET | `/enterprise/recruit/jobs` | 列表生成任务 | 读 | session(会话) |  | page, pageSize, q, city |  | data |
| `Recruit_evaluatePost` | POST | `/enterprise/recruit/jobs/evaluate` | 发表评估 | 写 | session(会话) |  |  | jobId | data |
| `Recruit_matchJobs` | POST | `/enterprise/recruit/jobs/match` | 匹配生成任务 | 写 | session(会话) |  |  | limit | data |
| `Recruit_getProfile` | GET | `/enterprise/recruit/profile` | 获取档案 | 读 | session(会话) |  |  |  | data |
| `Recruit_saveProfile` | POST | `/enterprise/recruit/profile/save` | 保存档案 | 写 | session(会话) |  |  | fullName, headline, years, city, expectedSalary, objectiveRole, skills, experiences, educations, summary | data |
| `Recruit_optimizeResume` | POST | `/enterprise/recruit/resume/optimize` | 优化简历 | 写 | session(会话) |  |  | jobId | data |

返回 `INDEX.md`。

